package com.ey.security;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.util.AntPathMatcher;
import org.springframework.web.filter.OncePerRequestFilter;
import com.ey.repository.AccountRepository;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class JWTAuthorizationFilter extends OncePerRequestFilter {

	private final JWTUtil jwtUtil;
	private final UserDetailsService userDetailsService;
	private final AccountRepository accountRepository;

	private final ObjectMapper objectMapper = new ObjectMapper();
	private final AntPathMatcher pathMatcher = new AntPathMatcher();

	
	private static final List<PublicEndpoint> PUBLIC_ENDPOINTS = List.of(
			new PublicEndpoint("/api/v1/auth/register", null), new PublicEndpoint("/api/v1/auth/login", null),
			new PublicEndpoint("/api/v1/auth/forgot-password", null),
			new PublicEndpoint("/api/v1/auth/reset-password", null),
			new PublicEndpoint("/api/v1/destinations/**", HttpMethod.GET.name()),
			new PublicEndpoint("/api/v1/packages/**", HttpMethod.GET.name()),
			new PublicEndpoint("/api/v1/trip-plans/**", HttpMethod.GET.name()),
			new PublicEndpoint("/api/v1/guides/**", HttpMethod.GET.name()));

	public JWTAuthorizationFilter(JWTUtil jwtUtil, UserDetailsService userDetailsService,
			AccountRepository accountRepository) {
		this.jwtUtil = jwtUtil;
		this.userDetailsService = userDetailsService;
		this.accountRepository = accountRepository;
	}

	@Override
	protected boolean shouldNotFilter(HttpServletRequest request) {
		String path = request.getServletPath();
		String method = request.getMethod();

		
		if (HttpMethod.OPTIONS.matches(method)) {
			return true;
		}

		for (PublicEndpoint ep : PUBLIC_ENDPOINTS) {
			if (pathMatcher.match(ep.pattern(), path)
					&& (ep.method() == null || ep.method().equalsIgnoreCase(method))) {
				return true;
			}
		}

		return false;
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {

		try {
			String token = jwtUtil.resolveToken(request);

			if (token != null && SecurityContextHolder.getContext().getAuthentication() == null) {
				String username = jwtUtil.extractUsername(token);

				if (username != null) {
					
					var accountOpt = accountRepository.findByEmail(username);
					if (accountOpt.isEmpty() || !accountOpt.get().isActive()) {
						unauthorized(response, "Account is disabled or not found");
						return;
					}

					UserDetails userDetails = userDetailsService.loadUserByUsername(username);
					if (jwtUtil.validateToken(token, userDetails)) {
						UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(
								userDetails, null, userDetails.getAuthorities());
						authToken.setDetails(
								new org.springframework.security.web.authentication.WebAuthenticationDetailsSource()
										.buildDetails(request));
						SecurityContextHolder.getContext().setAuthentication(authToken);
					} else {
						unauthorized(response, "Invalid or expired token");
						return;
					}
				}
			}

			filterChain.doFilter(request, response);
		} catch (io.jsonwebtoken.ExpiredJwtException e) {
			unauthorized(response, "Token expired");
		} catch (io.jsonwebtoken.JwtException e) {
			unauthorized(response, "Invalid token");
		} catch (Exception e) {
			unauthorized(response, "Authorization error: " + e.getMessage());
		}
	}

	private void unauthorized(HttpServletResponse response, String message) throws IOException {
		
		response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
		response.setContentType(MediaType.APPLICATION_JSON_VALUE);
		Map<String, Object> body = new HashMap<>();
		body.put("error", "Unauthorized");
		body.put("message", message);
		objectMapper.writeValue(response.getOutputStream(), body);
	}

	private record PublicEndpoint(String pattern, String method) {
	}
}
