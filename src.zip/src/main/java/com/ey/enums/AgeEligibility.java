package com.ey.enums;

public enum AgeEligibility {
	FAMILY, SENIOR, YOUTH
}
