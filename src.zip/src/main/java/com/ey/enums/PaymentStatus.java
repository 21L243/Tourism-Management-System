package com.ey.enums;

public enum PaymentStatus {
	INITIATED, SUCCESS, FAILED
}