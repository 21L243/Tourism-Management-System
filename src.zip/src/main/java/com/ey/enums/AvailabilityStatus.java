package com.ey.enums;

public enum AvailabilityStatus {
	AVAILABLE, BUSY
}
