package com.ey.enums;

public enum DiscountType {
	PERCENTAGE, FLAT
}