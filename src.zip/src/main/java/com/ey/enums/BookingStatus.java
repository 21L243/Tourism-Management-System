package com.ey.enums;

public enum BookingStatus {
	PENDING, CONFIRMED, CANCELLED
}
