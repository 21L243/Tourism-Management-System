package com.ey.enums;

public enum Role {
	USER, ADMIN
}
